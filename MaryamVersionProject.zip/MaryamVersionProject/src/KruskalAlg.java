
import java.io.PrintWriter;
import java.util.*;

public class KruskalAlg extends MSTAlgorithm {

    //output MSTAlgorithm
    private LinkedList<Road> MSTResultList = new LinkedList<>();

    public KruskalAlg() {
    }

    public void applyKruskal(Graph g, PrintWriter output) {
        // start time
        long StartTime = System.currentTimeMillis();
        // get Adjacencylist of g
        LinkedList<Road>[] allEdges = g.getAdjacencylist();
        // new PriorityQueue that order edge according to weight
        PriorityQueue<Road> priorityQueueVar = new PriorityQueue<>(g.getEdgeNo(), Comparator.comparingInt(o -> o.getWeight()));

        //call the method to sort the array base on the weight
        sortWeight(allEdges, priorityQueueVar);

        //create a parent []
        int parent[] = new int[g.getVerticesNo()];

        //makeset using the parent created
        makeSet(parent);

        //check if the vertix is a char or int
        //if its a char
        //call  method charKruskal
        if (g.getIsChar()) {
            charKruskal(g, parent, priorityQueueVar);
            displayResultingMSTChar(output);
        } //else if its integer
        //call method intKruskal
        else {
            intKruskal(g, parent, priorityQueueVar);
            displayResultingMST(output);
        }

        //finish time of the algorithm
        long FinishTime = System.currentTimeMillis();
        //print the total time consumed by the algorithm
        output.println("Total runtime of Kruskal's Algorithm: " + (FinishTime - StartTime) + " ms.");

    }

    //this method sorts edges based on their weights
    public void sortWeight(LinkedList<Road>[] allEdges, PriorityQueue<Road> priorityQueueVar) {

        //add all the edges to priority queue
        //sort the edges depending on weights
        for (LinkedList<Road> allEdge : allEdges) {
            for (int j = 0; j < allEdge.size(); j++) {
                priorityQueueVar.add(allEdge.get(j));
            }
        }

    }

    // Kruskal for charecter verts (houses with char labels)
    public void charKruskal(Graph g, int parent[], PriorityQueue<Road> priorityQueueVar) {

        int index = 0;
        while (index < g.getVerticesNo() - 1 && !priorityQueueVar.isEmpty()) {
            // take edge from priorityQueue
            Road edge = priorityQueueVar.remove();
            //check if adding this edge creates a cycle
            int x_set = find(parent, edge.getSource().getVertPos());

            int y_set = find(parent, edge.getDestination().getVertPos());

            if (x_set == y_set) {
                //if x_set = y_set ignore as it will create cycle
            } else {
                //otherwise add it to our final result list, increase the index, and invoke the union method
                MSTResultList.add(edge);
                index++;
                union(parent, x_set, y_set);
            }
        }

    }

    // Kruskal for integer vetireces
    public void intKruskal(Graph g, int parent[], PriorityQueue<Road> priorityQueueVar) {

        int index = 0;
        while (index < g.getVerticesNo() - 1 && !priorityQueueVar.isEmpty()) {
            // take edge from priorityQueue
            Road edge = priorityQueueVar.remove();
            //check if adding this edge creates a cycle
            int x_set = find(parent, edge.getSource().getLabelI());

            int y_set = find(parent, edge.getDestination().getLabelI());

            if (x_set == y_set) {
                //ignore as it will create cycle
            } else {
                //add it to our final result list, increase index, and invoke union method
                MSTResultList.add(edge);
                index++;
                union(parent, x_set, y_set);
            }
        }
    }

    public void makeSet(int[] parent) {
        for (int i = 0; i < parent.length; i++) {
            parent[i] = i;
        }
    }

    public int find(int[] parent, int i) {
        if (parent[i] != i) {
            return find(parent, parent[i]);
        }
        return i;
    }

    public void union(int[] parent, int x, int y) {
        int x_set_parent = find(parent, x);
        int y_set_parent = find(parent, y);
        parent[y_set_parent] = x_set_parent;
    }

    @Override
    public void displayResultingMST(PrintWriter output) {
        int total_min_weight = 0;
        output.println("------------ Running Kruskal's Alg ------------");
        for (int i = 0; i < MSTResultList.size(); i++) { // Loop to print edge information
            Road edge = MSTResultList.get(i);
            //output.println("Edge from " + edge.getSource().getLabelI() + " to " + edge.getDestination().getLabelI() + " has weight " + edge.getWeight());
            total_min_weight += edge.getWeight();
        }
        //output.println("Total minimum key: " + total_min_weight); 

    }

    public void displayResultingMSTChar(PrintWriter output) {
        int total_min_weight = 0;
        output.println("\n------------ Running Kruskal's Alg ------------\n");
        for (int i = 0; i < MSTResultList.size(); i++) { // Loop to print edge information
             Road road = MSTResultList.get(i);
            //road.getSource() is a House object, it will print House info 
            road.getSource().displayInfo(output);
            output.print(" - ");
            //road.getDestination() is a House object, it will print House info
            road.getDestination().displayInfo(output);
            //road is a Road object, it will print road name and road size
            road.displayInfo(output);
            total_min_weight += road.getWeight();
        }
        output.println("\nThe cost of the designed roads: " + total_min_weight); //To change body of generated methods, choose Tools | Templates.

    }

}
