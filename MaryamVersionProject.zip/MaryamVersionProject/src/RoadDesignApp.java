import java.io.*;
import java.util.*;

public class RoadDesignApp {

    public static void main(String[] args) throws FileNotFoundException {
        File input = new File("input.txt");
        File file = new File("output.txt");
        File file2 = new File("output2.txt");
        File file3 = new File("output3.txt");
        PrintWriter output = new PrintWriter(file);
        PrintWriter output2 = new PrintWriter(file2);
        PrintWriter o3 = new PrintWriter(file3);
        Scanner insert = new Scanner(System.in);
        int algonum = -1;

        while (algonum != 1 && algonum != 2) {
            System.out.println("********Comparison of two of the minimum-spanning-tree algorithms ");
            System.out.println("1- Read a Graph from a file");
            System.out.println("2- Generate a Random Graph");
            System.out.print("Enter your choice: ");
            algonum = insert.nextInt();

            if (algonum != 1 && algonum != 2) {
                System.out.println("****Wrong input!");
            }

            //creat a new graph
            Graph g = new Graph();

            switch (algonum) {
                case 1: {

                    Graph done = g.readGraphFromFile(input,o3);

                    //Kruskal Algorithm
                    KruskalAlg MST = new KruskalAlg();
                    MST.applyKruskal(done, o3);

                    PQPrimAlg MST2 = new PQPrimAlg();
                    MST2.prim_PQ(done, o3, true);
                }
                break;
                case 2: {

                    for (int i = 0; i < 10; i++) {

                        output.println("-------------------------------------------------------------");
                        output.println("------------------------    iteration: " + i + "------------------------");
                        output.println("-------------------------------------------------------------");

                        output2.println("-------------------------------------------------------------");
                        output2.println("------------------------    iteration: " + i + "------------------------");
                        output2.println("-------------------------------------------------------------");

                        KruskalAlg MST = new KruskalAlg();
                        PQPrimAlg MST_P = new PQPrimAlg();

                        /*
                    in case two ,we will create a random graph , while n = the number of vertices  and m = number of edges 
                    The following is the list of n and m we will create using make_graph method
                      n=1000 and m={10000, 15000, 25000}, 
                      n=5000 and m={15000, 25000},
                      n=10000 and m={15000, 25000} */
                        //  n=1000 number of vertices   
                        //m= 10000 number of edges
                        //Kruskal Algorithm
                        Graph done1 = new Graph(1000,10000);
                        done1.make_graph(done1);
                        MST.applyKruskal(done1, output);

                        //Priority-queue Prim Algorithm
                        MST_P.prim_PQ(done1, output2, false);

                        //m= 15000 number of edges    
                        //Kruskal Algorithm
                         Graph done2 = new Graph(1000, 15000);
                         done2.make_graph(done2);
                         MST.applyKruskal(done2, output);

                        //Priority-queue Prim Algorithm
                        MST_P.prim_PQ(done2, output2, false);

                        //m= 25000 number of edges  
                        //Kruskal Algorithm
                        Graph done3 = new Graph(1000, 25000);
                        done3.make_graph(done3);
                        MST.applyKruskal(done3, output);

                        //Priority-queue Prim Algorithm
                        MST_P.prim_PQ(done3, output2, false);

                        //----------------------------------------------------
                        //  n=5000 number of vertices 
                        //m= 15000 number of edges
                        //Kruskal Algorithm
                        Graph done4 = new Graph(5000, 15000);
                        done4.make_graph(done4);
                        MST.applyKruskal(done4, output);

                        //Priority-queue Prim Algorithm
                        MST_P.prim_PQ(done4, output2, false);

                        //m= 25000 number of edges
                        //Kruskal Algorithm
                        Graph done5 = new Graph(5000, 25000);
                        done5.make_graph(done5);
                        MST.applyKruskal(done5, output);

                        //Priority-queue Prim Algorithm
                        MST_P.prim_PQ(done5, output2, false);

                        //----------------------------------------------------        
                        //  n=10000 number of vertices   
                        //m= 15000 number of edges
                        //Kruskal Algorithm
                        Graph done6 = new Graph(10000, 15000);
                        done6.make_graph(done6);
                        MST.applyKruskal(done6, output);

                        //Priority-queue Prim Algorithm
                        MST_P.prim_PQ(done6, output2, false);

                        //m= 25000 number of edges                        
                        //Kruskal Algorithm
                        Graph done7 = new Graph(10000, 25000);
                        done7.make_graph(done7);
                        MST.applyKruskal(done7, output);

                        //Priority-queue Prim Algorithm
                        MST_P.prim_PQ(done7, output2, false);
                    }

                }
                break;
            }
            
            

        }
        output.println("done!");
        output2.println("done!");
        o3.println("done!");

        output.close();
        output2.close();
        o3.close();
    }

}
