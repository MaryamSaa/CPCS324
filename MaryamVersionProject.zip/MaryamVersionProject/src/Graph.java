
import java.io.*;
import java.util.*;

public class Graph {

    private int verticesNo;//number of vertices of the graph
    private int edgeNo;//number of edges of the graph.
    private boolean isDigraph = false, isChar = false;//boolean that is set to true if the graph is directed graph 

    public static ArrayList<House> vertices = new ArrayList<House>();//list of vertices of a graph.
    public static LinkedList<Road>[] adjacencylist;//an array of linked lists

    public Graph(int verticesNo, int edgeNo) {
        this.verticesNo = verticesNo;
        this.edgeNo = edgeNo;
        adjacencylist = new LinkedList[verticesNo];

        //initialize adjacency lists for all the vertices
        for (int i = 0; i < verticesNo; i++) {
            adjacencylist[i] = new LinkedList<>();
        }
    }

    public Graph() {
    }

    public Graph readGraphFromFile(File fileName, PrintWriter out3) throws FileNotFoundException {

        Scanner input = new Scanner(fileName);//Scanner to read form the input file

        String dLabel = input.next(); // to read "diagraph"
        int digraph = input.nextInt(); //if it's 1, it's a digraph
        int max_verts = input.nextInt();
        int edgesnum = input.nextInt();
        isChar =true; //isChar is true because we are reading char vertices here...
        
        Graph g = new Graph(max_verts, edgesnum);
        if (digraph == 1) {
            g.setIsDigraph(true); // set digraph to true if input = 1
        }

        // loop over whole file
        while (input.hasNext()) {
            // create two house objects, v=source and u=destination
            House v;
            House u;

            // create a new House object using char
            char s = input.next().charAt(0);
            // first in the parameter is label as an int ... aka its position
            v = new House((int)(s-65), s, false); 
            
            //create a new House object
            char d = input.next().charAt(0);
            u = new House((int)(d-65),d,false); 
            
            // send weight
            int w = input.nextInt();

            //add the edge to the graph
            //last parameter is isChar
            g.addEdge(v, u, w, true);
        }
        g.setIsChar(true);

        out3.println("------------ Reading Graph from File ------------");
        for (int i = 0; i < adjacencylist.length; i++) { 
            LinkedList<Road> list = adjacencylist[i];
            for (int j = 0; j < list.size(); j++) {
                Road road = list.get(j); 
                // road.getSource() is a House object, so it will display src House info
                road.getSource().displayInfo(out3);
                out3.print(" - ");
                // road.getDestination() is a House object, so it will display dest House info
                road.getDestination().displayInfo(out3);
                // this is a Road object, will display road name and road size info
                road.displayInfo(out3);   
            }
        }
        return g;
    }

    public void make_graph(Graph graph) {
        // instance of Random class
        isChar =false;
        Random random = new Random();
        // ensure that all vertices are connected
        for (int i = 0; i < vertices.size() - 1; i++) {
            int RandomNum = random.nextInt(10) + 1;
            addEdge(vertices.get(i), vertices.get(i+1), RandomNum, false);

        }

        // generate random graph with the remaining edges
        int remaining = edgeNo - (vertices.size() - 1);

        //iterate over the remaining edges
        for (int i = 0; i < remaining; i++) {
            // make a random number
            int r = (int)(Math.random()*verticesNo);
            // use that random number as int label, and char label to make House object "src"
            // (char)(r+65) makes the int into a char label ... for example 0+65 = 'A'
            House src = new House(r, (char)(r+65), false);
            
            // new random number to make house object "dest"
            r = (int)(Math.random()*verticesNo);
            House dest = new House(r, (char)(r+65), false);
            
            if (dest.getLabelI() == src.getLabelI() || isConnected(src, dest, graph.adjacencylist)) { // to avoid self loops and duplicate edges
                i--;
                continue;
            }
            // generate random weights in range 0 to 20
            int weight = random.nextInt(20) + 1;
            // add edge to the graph
            addEdge(src, dest, weight, false);
        }
    }


    public Road addEdge(House v, House u, int w, boolean isChar) {
        // Road edge = new Road(v, u, w);
        // adjacencylist[v.getLabel()].addFirst(edge);

        // initialize road object e with null values in order to be able to return it ...
        Road e = new Road(null, null, -100);
        Road e2;
        
        // if isChar = true
        if (isChar) {

            // if the House(vertex) label is unique, make a new Road object with those labels.
            if (isVertLabelUnique(v) && isVertLabelUnique(u)) {
                e = new Road(v, u, w);
                adjacencylist[e.getSource().getVertPos()].addFirst(e); // add it to the adjacencylist
            }

            //increase the number of edges
            edgeNo++;

        } else { // else if it's not a char ... get Integer Label
            Road edge = new Road(v, u, w);
            adjacencylist[v.getLabelI()].addFirst(edge); 
        }

        /* if (isDigraph == false && v.getLabel() != u.getLabel()){
            e2 = new Road (u, v, w);
            adjacencylist[v.getLabel()].addFirst(e2);
            edgeNo++;
        }*/
        return e;
    }

    public boolean isVertLabelUnique(House v) {
        // add vert to vertices list if it is unique and increase the number of vertices
        for (int i = 0; i < vertices.size(); i++) {
            if (v.getLabel() == vertices.get(i).getLabel()) {
                return false;
            }
            vertices.add(v);
            verticesNo++;
        }
        return true;
    }

    public boolean isConnected(House v, House u, LinkedList<Road>[] temp) {
        LinkedList<Road> templ;
        for (LinkedList<Road> temp1 : temp) {
            templ = temp1;// take temp of each linkedList in the array 
            for (int j = 0; j < templ.size(); j++) {
                //check if v and u have any edges
                // no need to check if source of edge = to u and destination = to v since we did it in makeGraph function
                if ((templ.get(j).getSource().getLabelI() == v.getLabelI() && templ.get(j).getDestination().getLabelI() == u.getLabelI())) {
                    return true;
                }
            }
        }
        return false;

    }


    public int getVerticesNo() {
        return verticesNo;
    }

    public void setVerticesNo(int verticesNo) {
        this.verticesNo = verticesNo;
    }

    public int getEdgeNo() {
        return edgeNo;
    }

    public void setEdgeNo(int edgeNo) {
        this.edgeNo = edgeNo;
    }

    public boolean isIsDigraph() {
        return isDigraph;
    }

    public void setIsDigraph(boolean isDigraph) {
        this.isDigraph = isDigraph;
    }

    public ArrayList<House> getVertices() {
        return vertices;
    }

    public LinkedList<Road>[] getAdjacencylist() {
        return adjacencylist;
    }

    public void setAdjacencylist(LinkedList<Road>[] adjacencylist) {
        this.adjacencylist = adjacencylist;
    }

    public boolean getIsChar() {
        return isChar;
    }

    public void setIsChar(boolean isChar) {
        this.isChar = isChar;
    }
}
