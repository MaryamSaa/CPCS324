
import java.io.PrintWriter;

public class Edge {
    int weight = 1;

    public Edge(){
        
    }
    
    public Edge(int weight){
        this.weight = weight;
    }
    
    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }
    
    public void displayInfo(PrintWriter out){
        //print road size, where road size = weight * 20 as per the output given.
        out.println(" road size: " + (getWeight()*20));
    }
}
