
import java.io.PrintWriter;


public class Road extends Edge implements Comparable<Road> {
    private House source;
    private House destination;
    private House parent = new House(-1, (char)(-1+65), false);

    public Road(House source, House destination, int weight) {
        
        super(weight);
        this.source = source;
        this.destination = destination;
        this.parent = source;
    }

    public Road(House source, House destination) {
        this.source = source;
        this.destination = destination;
    }

    public Road() {
    }

    public House getSource() {
        return source;
    }

    public void setSource(House source) {
        this.source = source;
    }

    public House getDestination() {
        return destination;
    }

    public void setDestination(House destination) {
        this.destination = destination;
    }

    public House getParent() {
        return parent;
    }

    public void setParent(House parent) {
        this.parent = parent;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    @Override
    public int compareTo(Road edgeToCompare) {
        return this.weight - edgeToCompare.getWeight();
    }
    
    @Override
    public void displayInfo(PrintWriter out){
        // print unique road name, by getting the int label and adding 1
        // for example for house A, since it has int label 0, add 1 to it in order to get road name x1
        out.print("road name: road x" + (getSource().getLabelI()+1));
        //get road size (weight) from super by invoking displayInfo from class Edge
        super.displayInfo(out);
    }

}
