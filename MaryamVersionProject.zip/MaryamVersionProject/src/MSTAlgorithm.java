import java.io.PrintWriter;
import java.util.LinkedList;

public abstract class MSTAlgorithm {
     public static LinkedList<Road> MSTResultList;
    
    abstract public void displayResultingMST(PrintWriter output);
    
    
    static class HeapNode {

        int vertex;
        int key;
    }

    static class ResultSet {

        int parent = 0;
        int destination  = 0;
        int weight = 0;
    }
}
