
import java.io.*;
import java.util.*;
import javafx.util.Pair;

public class PQPrimAlg extends MSTAlgorithm {

    public void prim_PQ(Graph g, PrintWriter output, boolean ischar) {
        LinkedList<Road>[] adjList = g.getAdjacencylist();
        int verts = g.getVerticesNo();
        //start calculating time here 
        long startTime = System.currentTimeMillis();
        boolean[] MST = new boolean[verts];
        ResultSet[] results = new ResultSet[verts];
        int[] key = new int[verts];

        // initialize keys to max value
        // initialize resultSet
        for (int i = 0; i < verts; i++) {
            key[i] = Integer.MAX_VALUE;
            results[i] = new ResultSet();
        }

        // initialize priority queue
        // override the comparator in order to sort the keys
        PriorityQueue<Pair<Integer, Integer>> PQ = new PriorityQueue<>(verts,
                (Pair<Integer, Integer> p1, Pair<Integer, Integer> p2) -> {
                    //sort using key values
                    int key1 = p1.getKey();
                    int key2 = p2.getKey();
                    return key1 - key2;
                });

        //create a pair for the first index,where 0 key 0 index
        key[0] = 0;
        Pair<Integer, Integer> p0 = new Pair<>(key[0], 0);
        //add pair to priority queue
        PQ.offer(p0);
        results[0] = new ResultSet();
        results[0].parent = 0;

        if (ischar) {
            //loop while priority queue is not empty
            while (!PQ.isEmpty()) {
                //extract smallest value
                Pair<Integer, Integer> pair_extract = PQ.poll();

                //extract vertex
                int exVert = pair_extract.getValue();
                MST[exVert] = true;

                //iterate through all adjacent verices and update keys
                LinkedList<Road> list = adjList[exVert];

                for (int i = 0; i < list.size(); i++) {
                    Road road = list.get(i);

                    //if edge destination is not currently present in mst
                    if (MST[road.getDestination().getVertPos()] == false) {
                        int destination = road.getDestination().getVertPos();
                        int newKey = road.getWeight();
                        //check if updated key < current key
                        //if true-> update
                        if (key[destination] > newKey) {
                            //add it to priority queue
                            Pair<Integer, Integer> pq_updated = new Pair<>(newKey, destination);
                            PQ.offer(pq_updated);

                            //update the ResultSet for destination vertex
                            results[destination].parent = exVert;
                            results[destination].weight = newKey;
                            results[destination].destination = destination;
                            //update key array
                            key[destination] = newKey;

                        }

                    }

                }
            }
        } else {
            while (!PQ.isEmpty()) {
                //extract the smallest value
                Pair<Integer, Integer> pair_extract = PQ.poll();

                //extract vertex
                int pastVert = pair_extract.getValue();
                MST[pastVert] = true;

                //iterate through adjacent verices and update keys
                LinkedList<Road> list = adjList[pastVert];

                for (int i = 0; i < list.size(); i++) {
                    Road edg = list.get(i);

                    //if edge destination is not in mst
                    if (MST[edg.getDestination().getLabelI()] == false) {
                        int destination = edg.getDestination().getLabelI();
                        int newKey = edg.getWeight();
                        //now check if updated key < current key , if it is then update values
                        if (key[destination] > newKey) {
                            //add updated values to priority queue
                            Pair<Integer, Integer> pq_updated = new Pair<>(newKey, destination);
                            PQ.offer(pq_updated);

                            //update ResultSet for destination House (vertex)
                            results[destination].parent = pastVert;
                            results[destination].weight = newKey;
                            results[destination].destination = destination;
                            //update key array
                            key[destination] = newKey;

                        }

                    }

                }
            }
        }
        //calcuate fin time
        long finTime = System.currentTimeMillis();

        //print total time taken by the algorithm and mst
        displayResultingMST(results, output, ischar);
        output.println("Total runtime of Prim's Algorithm (Using Priority Queue): " + (finTime - startTime) + " ms.");
    }

    public void displayResultingMST(ResultSet[] resultSet, PrintWriter output, boolean isChar) {
        int verts = resultSet.length;
        int totalWeight = 0, i = 1;
        output.println("\n\n------------ Running Prim's Alg ------------\n");
        while (i < verts) {
            totalWeight += resultSet[i].weight;

            if (isChar) {
                House src = new House(resultSet[i].parent, (char)(resultSet[i].parent+65), true);
                House dest = new House(resultSet[i].destination, (char)(resultSet[i].destination+65), true);
                Road road = new Road(src, dest, resultSet[i].weight);
                road.getSource().displayInfo(output);
                output.print(" - ");
                road.getDestination().displayInfo(output);
                road.displayInfo(output);
            }

            i++;
        }
        output.println("\nThe cost of the designed roads: " + totalWeight); 

    }

    @Override
    public void displayResultingMST(PrintWriter output) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
