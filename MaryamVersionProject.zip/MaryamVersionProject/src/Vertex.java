
import java.io.PrintWriter;

public class Vertex {
    int labelI;
    boolean isVisited = false;

    public Vertex(int labelI,boolean isVisited) {
        this.labelI = labelI;
        this.isVisited = isVisited;
    }

    public Vertex(){
        
    }
    
    public int getLabelI() {
        return labelI;
    }

    public void setLabelI(int labelI) {
        this.labelI = labelI;
    }


    public boolean isIsVisited() {
        return isVisited;
    }

    public void setIsVisited(boolean isVisited) {
        this.isVisited = isVisited;
    }
    
    public void displayInfo(PrintWriter out){
        // print the label as a Char
        // add 65 to int label
        out.print((char)(getLabelI()+65) + " ");
    }
}
