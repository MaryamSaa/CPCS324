
import java.io.PrintWriter;
import java.util.LinkedList;

public class House extends Vertex{

    private char label;//char lable
    private final char labels[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();// araay of cahr labels to denote vertex position 
    private int position;
    static LinkedList<Road>[] adjacencylist; //to represents the adjacency list of a vertex
    private boolean isChar = false;
    int parent = -1; 

    public House(){
        
    }
    

    public House (int labelI, char labelC, boolean isVisited){
        //get integer label, and isVisited from super
        super(labelI,isVisited);
        
        // convert int label to char label by adding 65
        labelC = (char)(labelI+65);
        this.label = labelC;   
    }

    public void setLabel(char label) {
        this.label = label;
    }

    public char getLabel() {
        return label;
    }


    public LinkedList<Road>[] getAdjacencylist() {
        return adjacencylist;
    }

    public void setAdjacencylist(LinkedList<Road>[] adjacencylist) {
        this.adjacencylist = adjacencylist;
    }

    public int getVertPos() {
        //if label found retrun its index 
        //if not found return -1
        for (int i = 0; i < labels.length; i++) {
            if (labels[i] == label) {
                return i;
            }
        }
        return -1;
    }

    public void setIsChar(boolean isChar) {
        this.isChar = isChar;
    }

    public boolean isIsChar() {
        return isChar;
    }
    
    @Override
    public void displayInfo(PrintWriter out){
        //print "House Name." and invoke super displayInfo to get the House Label from class Vertex
        out.print("House Name. ");
        super.displayInfo(out);
        
    }

}
